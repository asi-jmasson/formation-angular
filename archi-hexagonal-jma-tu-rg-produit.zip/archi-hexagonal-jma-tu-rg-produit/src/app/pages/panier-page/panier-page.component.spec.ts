import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { PanierModule } from 'src/app/modules/panier/panier.module';
import { ProduitsPanierService } from 'src/app/modules/produits/services/produits-panier.service';

import { PanierPageComponent } from './panier-page.component';

describe('PanierPageComponent', () => {
  let component: PanierPageComponent;
  let fixture: ComponentFixture<PanierPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PanierModule, HttpClientTestingModule, MatDialogModule],
      declarations: [ PanierPageComponent ],
      providers: [ProduitsPanierService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanierPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
