import { Injectable } from '@angular/core';
import { Configuration, ConfigurationParameters } from 'openapi/build/configuration';
import { environment } from 'src/environments/environment';

/**
 * Ce service permet de charger des configurations dynamiques pour l'API.
 */
@Injectable({
  providedIn: 'root'
})
export class ApiConfigurationService {

  constructor() { }
}


/**
 * Retourne les paramêtres de configuration de l'API.
 */
 // eslint-disable-next-line prefer-arrow/prefer-arrow-functions
 export function apiConfigFactory(): Configuration {
  const params: ConfigurationParameters = {
    // set configuration parameters here.
    basePath: environment.apiBasePath,
    // activer les credentials pour l'authentification sur l'API.
    withCredentials: true,
  };

  return new Configuration(params);
}
