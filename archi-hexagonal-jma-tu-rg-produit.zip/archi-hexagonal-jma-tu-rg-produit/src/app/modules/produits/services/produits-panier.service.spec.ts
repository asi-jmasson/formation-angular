import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { ProduitsRestService } from 'openapi/build';
import { ProduitsPanierService } from './produits-panier.service';

describe('ProduitsPanierService', () => {
  let service: ProduitsPanierService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, MatDialogModule],
      providers: [
        ProduitsRestService,
      ]
    });
    service = TestBed.inject(ProduitsPanierService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
