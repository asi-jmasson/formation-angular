import { Injectable } from '@angular/core';
import { ProduitsRestService } from 'openapi/build';
import { IProduitService } from './abstract-produit.service';
import { AlerteProduitPanierService as IAlerteProduitService } from './alerte/alerte-produit-panier.service';
import { ProduitsService } from './produits.service';

/**
 * Service Produits - Métier
 * @override ProduitsService avec une alerte de type AlerteProduitPanierService.
 */
@Injectable({
  providedIn: 'root'
})
export class ProduitsPanierService extends ProduitsService implements IProduitService {

  constructor(public produitsRestService: ProduitsRestService,
              public alerteProduitService: IAlerteProduitService) {
    super(produitsRestService, alerteProduitService);
  }
}
