import { MatDialog } from "@angular/material/dialog";
import { MessageAlerte } from "./message-alerte.model";

/**
 * Interface Alerte
 */
export abstract class IAlerteProduitService {

  constructor(public dialogRef: MatDialog) {
  }

  public abstract alerteRupture(message: MessageAlerte);

}
