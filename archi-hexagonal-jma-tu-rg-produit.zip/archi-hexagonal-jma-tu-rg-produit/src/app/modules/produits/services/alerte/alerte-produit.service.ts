import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { IAlerteProduitService } from './abstract-alerte';
import { AlerteDialogService } from './alerte-dialog.service';
import { MessageAlerte } from './message-alerte.model';

/**
 * Service de gestion de l'alerte produit.
 *
 */
@Injectable({
  providedIn: 'root'
})
export class AlerteProduitService extends AlerteDialogService implements IAlerteProduitService {

  constructor(public dialogRef: MatDialog) {
    super(dialogRef);
  }

  /**
   * @override alerteRupture()
   * @param message
   */
  public alerteRupture(message: MessageAlerte) {
    // méthode de AlerteDialogService
    this.openAlerte(message.message);
  }
}
