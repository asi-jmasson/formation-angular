import { TestBed } from '@angular/core/testing';
import { ProduitsRestService } from 'openapi/build';
import {
  HttpClientTestingModule,
} from '@angular/common/http/testing';
import { ProduitsService } from './produits.service';
import { MatDialogModule } from '@angular/material/dialog';
import { AlerteProduitService as IAlerteProduitService } from './alerte/alerte-produit.service';

describe('ProduitsService', () => {
  let service: ProduitsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, MatDialogModule],
      providers: [
        ProduitsRestService, IAlerteProduitService
      ]
    });
    service = TestBed.inject(ProduitsService);
    jest.spyOn(service.alerteProduitService, 'alerteRupture').mockReturnValue();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('RG testRupture', () => {
    const p = {
      nom: 'string',
      description: 'string',
      quantite: 5
    };

    //@ts-ignore
    service.testRupture(p);

    p.quantite = 4;
    //@ts-ignore
    service.testRupture(p);
    expect(service.alerteProduitService.alerteRupture).toHaveBeenCalledTimes(1);
  });
});


