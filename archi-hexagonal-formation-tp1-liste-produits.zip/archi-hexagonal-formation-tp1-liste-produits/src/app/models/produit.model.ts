import { Produit } from "openapi/build/model/produit";

export interface ProduitDC extends Produit {

}
