import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProduitDC } from 'src/app/models/produit.model';
import { PanierService } from '../panier/services/panier.service';

@Component({
  selector: 'app-panier-info-bulle',
  templateUrl: './panier-info-bulle.component.html',
  styleUrls: ['./panier-info-bulle.component.scss']
})
export class PanierInfoBulleComponent implements OnInit {

  public nbArticle = 0;

  constructor(private panierService: PanierService) { }

  ngOnInit(): void {
  }



}
