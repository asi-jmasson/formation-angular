import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PanierInfoBulleComponent } from './panier-info-bulle.component';

describe('PanierInfoBulleComponent', () => {
  let component: PanierInfoBulleComponent;
  let fixture: ComponentFixture<PanierInfoBulleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PanierInfoBulleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanierInfoBulleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
