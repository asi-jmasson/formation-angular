import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProduitDC } from 'src/app/models/produit.model';
import { PanierService } from './services/panier.service';

@Component({
  selector: 'app-panier',
  templateUrl: './panier.component.html',
  styleUrls: ['./panier.component.scss']
})
export class PanierComponent implements OnInit {

  public produits: ProduitDC[] = [];

  constructor() { }

  ngOnInit(): void {



  }



}
