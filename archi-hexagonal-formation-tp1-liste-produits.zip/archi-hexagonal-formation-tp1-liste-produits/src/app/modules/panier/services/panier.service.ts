import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { ProduitDC } from 'src/app/models/produit.model';

@Injectable({
  providedIn: 'root'
})
export class PanierService {


  constructor() { }


}
