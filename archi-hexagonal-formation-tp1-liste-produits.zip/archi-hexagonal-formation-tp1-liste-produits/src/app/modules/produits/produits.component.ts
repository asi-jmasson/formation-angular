import { Component, OnInit } from '@angular/core';
import { ProduitDC } from 'src/app/models/produit.model';
import { ProduitsService } from './services/produits.service';

@Component({
  selector: 'app-produits',
  templateUrl: './produits.component.html',
  styleUrls: ['./produits.component.scss']
})
export class ProduitsComponent implements OnInit {

  public produits: ProduitDC[] = [];

  constructor(private produitsService: ProduitsService) { }

  ngOnInit(): void {

    this.produitsService.getProduits().then((produits) => {
      if (produits.length > 0) {
        this.produits = produits;
      }
    });
  }



}
