import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProduitsComponent } from './produits.component';
import { ProduitModule } from '../produit/produit.module';



@NgModule({
  declarations: [
    ProduitsComponent
  ],
  imports: [
    CommonModule,
    ProduitModule,
  ],
  exports: [
    ProduitsComponent
  ]
})
export class ProduitsModule { }
