import { Injectable } from '@angular/core';
import { Produit } from 'openapi/build';
import { ProduitsRestService } from 'openapi/build/api/produitsRest.service';
import { ProduitDC } from 'src/app/models/produit.model';


@Injectable({
  providedIn: 'root'
})
export class ProduitsService {

  constructor(private produitsRestService: ProduitsRestService) { }

  getProduits(): Promise<ProduitDC[]> {

    return new Promise<ProduitDC[]>((resolve, reject) => {

        resolve( [
          {
            nom: 'chaise',
            description: 'description complete',
            quantite: 100
          },
          {
            nom: 'table',
            description: 'description complete',
            quantite: 50
          },
        ]);

    });


    /*
    return new Promise<ProduitDC[]>((resolve, reject) => {
      this.produitsRestService.produitsControllerGetProduits().subscribe((produits: Produit[])=> {
        resolve(produits);
      });
    });
    */
  }
}
