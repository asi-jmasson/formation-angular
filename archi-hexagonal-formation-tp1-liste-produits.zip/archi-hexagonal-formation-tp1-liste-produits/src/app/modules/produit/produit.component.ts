import { Component, Input, OnInit } from '@angular/core';
import { ProduitDC } from 'src/app/models/produit.model';
import { PanierService } from '../panier/services/panier.service';

@Component({
  selector: 'app-produit',
  templateUrl: './produit.component.html',
  styleUrls: ['./produit.component.scss']
})
export class ProduitComponent implements OnInit {

  public produit: ProduitDC;

  @Input()
  public isItemPanier = false;

  constructor(private panierService: PanierService) { }

  ngOnInit(): void {
  }

  public addProduit(p: ProduitDC) {

  }

}
