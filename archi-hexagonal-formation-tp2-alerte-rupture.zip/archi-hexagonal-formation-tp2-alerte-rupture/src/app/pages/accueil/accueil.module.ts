import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccueilRoutingModule } from './accueil-routing.module';
import { AccueilComponent } from './accueil.component';
import { ProduitsModule } from 'src/app/modules/produits/produits.module';
import { PanierModule } from 'src/app/modules/panier/panier.module';


@NgModule({
  declarations: [
    AccueilComponent
  ],
  imports: [
    CommonModule,
    AccueilRoutingModule,
    ProduitsModule,
    PanierModule,
  ]
})
export class AccueilModule { }
