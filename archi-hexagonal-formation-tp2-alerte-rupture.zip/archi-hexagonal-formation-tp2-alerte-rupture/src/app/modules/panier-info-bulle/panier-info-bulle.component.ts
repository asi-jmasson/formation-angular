import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProduitDC } from 'src/app/models/produit.model';
import { PanierService } from '../panier/services/panier.service';

@Component({
  selector: 'app-panier-info-bulle',
  templateUrl: './panier-info-bulle.component.html',
  styleUrls: ['./panier-info-bulle.component.scss']
})
export class PanierInfoBulleComponent implements OnInit {

  public nbArticle = 0;

  private panierSubscription: Subscription;

  constructor(private panierService: PanierService) { }

  ngOnInit(): void {

    this.panierSubscription = this.panierService.panierSubject.subscribe((produits: ProduitDC[])=> {
      this.nbArticle = produits.length;
    });

  }

  ngOnDestroy() {
    this.panierSubscription.unsubscribe();
  }


}
