import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProduitsComponent } from './produits.component';
import { ProduitModule } from '../produit/produit.module';
import { DialogErrorModule } from '../modals/dialog-error/dialog-error.module';
import { AlerteProduitService } from './services/alerte/alerte-produit.service';
import { ProduitsService } from './services/produits.service';



@NgModule({
  declarations: [
    ProduitsComponent
  ],
  imports: [
    CommonModule,
    ProduitModule,
    DialogErrorModule,
  ],
  providers: [
    // ! important pour la référence de MatDialog
    AlerteProduitService,
    ProduitsService,
  ],
  exports: [
    ProduitsComponent
  ]
})
export class ProduitsModule { }
