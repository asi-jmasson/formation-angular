import { Injectable } from '@angular/core';
import { Produit } from 'openapi/build';
import { ProduitsRestService } from 'openapi/build/api/produitsRest.service';
import { ProduitDC } from 'src/app/models/produit.model';
import { AlerteProduitService } from './alerte/alerte-produit.service';


@Injectable({
  providedIn: 'root'
})
export class ProduitsService {

  constructor(private produitsRestService: ProduitsRestService,
    private alerteProduitService: AlerteProduitService) { }

  getProduits(): Promise<ProduitDC[]> {

    // Todo : Afficher l'alerte si la quantité est inférieur à 5
    this.alerteProduitService.alerteRupture('Produit bientôt en rupture');

    return this.produitsRestService.produitsControllerGetProduits().toPromise();


    /*
    return new Promise<ProduitDC[]>((resolve, reject) => {
      this.produitsRestService.produitsControllerGetProduits().subscribe((produits: Produit[])=> {
        resolve(produits);
      });
    });
    */

    /*
    return [
      {
        nom: 'chaise',
        description: 'description complete',
        quantite: 100
      },
      {
        nom: 'table',
        description: 'description complete',
        quantite: 50
      },
    ];*/
  }
}
