import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogErrorComponent } from 'src/app/modules/modals/dialog-error/dialog-error.component';

@Injectable({
  providedIn: 'root'
})
export class AlerteProduitService {

  constructor(public dialogRef: MatDialog) {
  }

  public alerteRupture(message: string) {
    const dialogRef = this.dialogRef.open(DialogErrorComponent, { data: message });
  }
}
