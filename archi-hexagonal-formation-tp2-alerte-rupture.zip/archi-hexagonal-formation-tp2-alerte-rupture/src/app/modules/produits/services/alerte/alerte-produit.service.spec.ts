import { TestBed } from '@angular/core/testing';

import { AlerteProduitService } from './alerte-produit.service';

describe('AlerteProduitService', () => {
  let service: AlerteProduitService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlerteProduitService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
