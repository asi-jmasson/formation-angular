import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss']
})

/**
 * Ce composant est utilisé dans app.component.html
 */
export class MainLayoutComponent implements OnInit {

  @Input()
  public titre: string = 'TITRE 1';
  @Input()
  public srcLogo: string = 'assets/svg/logoApp.svg';

  public numVersionApp = '1.0.0';

  /**
   * Config du menu
   */
  public isMenuOpen = false;
  public contentMargin = 240;

  /**
   * Constructeur
   */
  constructor() { }

  ngOnInit() {
    this.isMenuOpen = true;  // Ouverture du menu par default
  }
}
