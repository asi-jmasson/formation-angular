import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.scss']
})
export class ProfilComponent implements OnInit {
  public userProfile;
  public profile = 'Administrateur';

  public async ngOnInit() {
    this.userProfile = {
      firstName: 'Testeur',
      lastName: 'TEST',
    };
  }

}
