const { defaults } = require('jest-config');

module.exports = {
    verbose: true,
    collectCoverage: true,
    collectCoverageFrom: [
        "./src/**/*.ts",
        "!./src/main.ts",
        "!./src/polyfills.ts",
        "!./src/**/*.module.ts",
        "!./src/environments/**/*"
    ],
    moduleNameMapper: {
      "^src/(.*)$": "<rootDir>/src/$1",
      "^openapi/(.*)$": "<rootDir>/openapi/$1"
    }
}
