import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogErrorComponent } from 'src/app/modules/modals/dialog-error/dialog-error.component';

/**
 * Service pour afficher la boite de dialoque.
 * Hérité par les services AlerteProduitPanierService et AlerteProduitService
 */
@Injectable({
  providedIn: 'root'
})
export class AlerteDialogService {

  constructor(public dialogRef: MatDialog) { }

  /**
   * Affiche la boite de dialogue d'avertissement
   * @param message
   */
  protected openAlerte(message: string) {
    const dialogRef = this.dialogRef.open(DialogErrorComponent, { data: message });
  }
}
