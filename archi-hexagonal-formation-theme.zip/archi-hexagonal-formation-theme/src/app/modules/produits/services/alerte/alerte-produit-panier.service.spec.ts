import { TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';

import { AlerteProduitPanierService } from './alerte-produit-panier.service';

describe('AlerteProduitPanierService', () => {
  let service: AlerteProduitPanierService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [MatDialogModule],
    });
    service = TestBed.inject(AlerteProduitPanierService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
