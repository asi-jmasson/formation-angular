import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainLayoutComponent } from './components/main-layout/main-layout.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { ProfilComponent } from './components/profil/profil.component';
import { MenuNavigationModule } from 'src/app/menu/menu-navigation/menu-navigation.module';
import { MenuProfilModule } from 'src/app/menu/menu-profil/menu-profil.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {  MatDividerModule } from '@angular/material/divider';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {HeaderModule} from '../../menu/header/header.module';



@NgModule({
  declarations: [
    MainLayoutComponent,
    ProfilComponent
  ],
  imports: [
    CommonModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,
    MenuProfilModule,
    MenuNavigationModule,
    RouterModule,
    ReactiveFormsModule,
    MatDividerModule,
    FormsModule,
    MatAutocompleteModule,
    HeaderModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  exports: [
    MainLayoutComponent
  ]
})
export class MaterialLayoutModule { }
