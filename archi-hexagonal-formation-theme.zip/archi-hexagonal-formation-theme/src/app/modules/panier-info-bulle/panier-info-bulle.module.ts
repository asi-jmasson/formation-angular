import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PanierInfoBulleComponent } from './panier-info-bulle.component';



@NgModule({
  declarations: [
    PanierInfoBulleComponent,
  ],
  imports: [
    CommonModule
  ],
  exports: [
    PanierInfoBulleComponent
  ]
})
export class PanierInfoBulleModule { }
