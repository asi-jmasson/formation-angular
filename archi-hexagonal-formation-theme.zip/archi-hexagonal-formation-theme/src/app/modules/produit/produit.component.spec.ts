import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PanierService } from 'src/app/modules/panier/services/panier.service';

import { ProduitComponent } from './produit.component';

describe('ProduitComponent', () => {
  let component: ProduitComponent;
  let fixture: ComponentFixture<ProduitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProduitComponent ],
      providers: [
        PanierService,
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProduitComponent);
    component = fixture.componentInstance;
    component.produit = {
      nom: 'chaise',
      quantite: 100,
      description: '',
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
