import { Component, OnInit } from '@angular/core';
import { ThemeService, Theme } from 'src/app/services/theme/theme.service';

@Component({
  selector: 'app-menu-profil',
  templateUrl: './menu-profil.component.html',
  styleUrls: ['./menu-profil.component.scss']
})
export class MenuProfilComponent implements OnInit {

  constructor(private themeService: ThemeService) {}

  public async ngOnInit(): Promise<void> {
  }

  public logout() {
  }

  public darkTheme() {
    this.themeService.changeTheme(Theme.SOMBRE);
  }

  public lightTheme() {
    this.themeService.changeTheme(Theme.NACRE);
  }
}
