import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuNavigationComponent } from './menu-navigation.component';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import {MatBadgeModule} from '@angular/material/badge';
import { PanierInfoBulleModule } from 'src/app/modules/panier-info-bulle/panier-info-bulle.module';


@NgModule({
  declarations: [
    MenuNavigationComponent
  ],
    imports: [
        CommonModule,
        MatListModule,
        MatIconModule,
        RouterModule,
        MatButtonModule,
        MatBadgeModule,
        PanierInfoBulleModule,
    ],
  exports: [
    MenuNavigationComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MenuNavigationModule {
}
