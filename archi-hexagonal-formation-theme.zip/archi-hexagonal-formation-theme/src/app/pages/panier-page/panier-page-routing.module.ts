import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PanierPageComponent } from './panier-page.component';

const routes: Routes = [
  {
    path: '',
    component: PanierPageComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PanierPageRoutingModule { }
