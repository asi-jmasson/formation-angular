import { Component, OnInit } from '@angular/core';
import { IProduitService } from 'src/app/modules/produits/services/abstract-produit.service';
import { ProduitsPanierService } from 'src/app/modules/produits/services/produits-panier.service';

@Component({
  selector: 'app-panier-page',
  templateUrl: './panier-page.component.html',
  styleUrls: ['./panier-page.component.scss'],
  providers: [
    {provide: IProduitService, useClass: ProduitsPanierService}
  ]
})
export class PanierPageComponent implements OnInit {

  constructor(private produitsService: IProduitService) { }

  ngOnInit(): void {

    this.produitsService.getProduits();
  }

}
