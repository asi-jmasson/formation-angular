import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PanierPageRoutingModule } from './panier-page-routing.module';
import { PanierPageComponent } from './panier-page.component';
import { PanierModule } from 'src/app/modules/panier/panier.module';
import { DialogErrorModule } from 'src/app/modules/modals/dialog-error/dialog-error.module';
import { AlerteProduitPanierService } from 'src/app/modules/produits/services/alerte/alerte-produit-panier.service';
import { ProduitsPanierService } from 'src/app/modules/produits/services/produits-panier.service';


@NgModule({
  declarations: [
    PanierPageComponent
  ],
  providers: [
    // ! important pour la r�f�rence de MatDialog
    AlerteProduitPanierService,
    ProduitsPanierService,
  ],
  imports: [
    CommonModule,
    PanierPageRoutingModule,
    PanierModule,
    DialogErrorModule,
  ]
})
export class PanierPageModule { }
