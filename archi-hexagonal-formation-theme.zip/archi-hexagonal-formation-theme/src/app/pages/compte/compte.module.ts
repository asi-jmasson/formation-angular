import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompteRoutingModule } from './compte-routing.module';
import { CompteComponent } from './compte.component';
import { FormulaireCompteModule } from './formulaire-compte/formulaire-compte.module';


@NgModule({
  declarations: [
    CompteComponent
  ],
  imports: [
    CommonModule,
    CompteRoutingModule,
    FormulaireCompteModule
  ]
})
export class CompteModule { }
