import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {

  private currentTheme: string = Theme.DEFAULT;

  constructor() { }

  public initTheme() {
    document.body.classList.add(Theme.DEFAULT);
  }

  public changeTheme(newTheme: string) {
    document.body.classList.remove(this.currentTheme);
    document.body.classList.add(newTheme);
    this.currentTheme = newTheme;
  }
}

export enum Theme {
  DEFAULT = 'default',
  NACRE = 'nacre',
  SOMBRE = 'sombre',
}
