export const environment = {
  production: true,

  apiBasePath: 'https://geofit-mclu.asi.fr/demo-api',
};
