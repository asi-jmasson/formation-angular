import { ComponentFixture, TestBed } from '@angular/core/testing';
import { KeycloakService } from 'keycloak-angular';
import { ProfilComponent } from './profil.component';
import { MatMenuModule } from '@angular/material/menu';
import { UserService } from 'src/app/modules/auth/services/user.service';



describe('ProfilComponent', () => {
  let component: ProfilComponent;
  let fixture: ComponentFixture<ProfilComponent>;

  const mockUserService = jasmine.createSpyObj('UserService', ['getProfiles']);
  let mockProvider = {
    loadUserProfile: () => { return new Promise((resolve, reject)=> {}); },
    isLoggedIn: () => { return new Promise((resolve, reject)=> {}); }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[MatMenuModule],
      declarations: [ ProfilComponent ],
      providers: [
        { provide: KeycloakService, useValue: mockProvider },
        { provide: UserService, useValue: mockUserService },
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
