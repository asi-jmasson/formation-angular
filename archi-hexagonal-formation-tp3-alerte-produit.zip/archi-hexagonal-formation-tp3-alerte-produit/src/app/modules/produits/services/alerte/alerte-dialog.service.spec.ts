import { TestBed } from '@angular/core/testing';

import { AlerteDialogService } from './alerte-dialog.service';

describe('AlerteDialogService', () => {
  let service: AlerteDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlerteDialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
