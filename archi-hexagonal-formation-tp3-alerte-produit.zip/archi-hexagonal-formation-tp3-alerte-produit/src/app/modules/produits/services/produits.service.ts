import { Injectable } from '@angular/core';
import { Produit } from 'openapi/build';
import { ProduitsRestService } from 'openapi/build/api/produitsRest.service';
import { ProduitDC } from 'src/app/models/produit.model';
import { AlerteProduitPanierService as IAlerteProduitService } from './alerte/alerte-produit-panier.service';
//import { AlerteProduitService as IAlerteProduitService } from './alerte/alerte-produit.service';
import { MessageAlertePanier as MessageAlerte } from './alerte/message-alerte.model';


/**
 * Service Produits - Métier
 */
@Injectable({
  providedIn: 'root'
})
export class ProduitsService {

  constructor(private produitsRestService: ProduitsRestService,
    private alerteProduitService: IAlerteProduitService) { }

    /**
     * Retourne une liste de produits
     * @returns
     */
  public getProduits(): Promise<ProduitDC[]> {

    return this.produitsRestService.produitsControllerGetProduits().toPromise().then((produits) => {

      produits.forEach((p) => {
        if (p.quantite < 5) {
          // RG : Afficher l'alerte si la quantité est inférieur à 5
          this.alerteProduitService.alerteRupture({
              message: 'Produit bientôt en rupture',
              produit: p.nom,
              quantite: p.quantite
            } as unknown as MessageAlerte);
        }
      });

      return produits;
    });


    /*
    return new Promise<ProduitDC[]>((resolve, reject) => {
      this.produitsRestService.produitsControllerGetProduits().subscribe((produits: Produit[])=> {
        resolve(produits);
      });
    });
    */

    /*
    return [
      {
        nom: 'chaise',
        description: 'description complete',
        quantite: 100
      },
      {
        nom: 'table',
        description: 'description complete',
        quantite: 50
      },
    ];*/
  }
}
