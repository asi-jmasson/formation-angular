import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { ProduitDC } from 'src/app/models/produit.model';

@Injectable({
  providedIn: 'root'
})
export class PanierService {

  private produits: ProduitDC[] = [];
  public panierSubject = new Subject<ProduitDC[]>();

  constructor() { }

  public emitUpdatePanier() {

    this.panierSubject.next(this.produits);
  }

  public addProduit(p: ProduitDC) {
    this.produits.push(p);

    this.emitUpdatePanier();
  }

  public get produitsList() : ProduitDC[] {
    return this.produits;
  }

}
