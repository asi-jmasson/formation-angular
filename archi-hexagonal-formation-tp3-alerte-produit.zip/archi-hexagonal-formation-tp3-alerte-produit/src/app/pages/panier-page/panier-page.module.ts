import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PanierPageRoutingModule } from './panier-page-routing.module';
import { PanierPageComponent } from './panier-page.component';
import { PanierModule } from 'src/app/modules/panier/panier.module';


@NgModule({
  declarations: [
    PanierPageComponent
  ],
  imports: [
    CommonModule,
    PanierPageRoutingModule,
    PanierModule,
  ]
})
export class PanierPageModule { }
