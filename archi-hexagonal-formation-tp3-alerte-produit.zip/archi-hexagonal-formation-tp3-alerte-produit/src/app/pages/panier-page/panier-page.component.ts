import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panier-page',
  templateUrl: './panier-page.component.html',
  styleUrls: ['./panier-page.component.scss']
})
export class PanierPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
