import { TestBed } from '@angular/core/testing';
import { DialogErrorComponent } from 'src/app/modules/modals/dialog-error/dialog-error.component';
import { DialogErrorModule } from 'src/app/modules/modals/dialog-error/dialog-error.module';

import { AlerteDialogService } from './alerte-dialog.service';

describe('AlerteDialogService', () => {
  let service: AlerteDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        DialogErrorModule
      ]
    });
    service = TestBed.inject(AlerteDialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
