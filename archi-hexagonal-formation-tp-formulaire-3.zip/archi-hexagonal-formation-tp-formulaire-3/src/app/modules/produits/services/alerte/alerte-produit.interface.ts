import { MatDialog } from "@angular/material/dialog";
import { MessageAlerte } from "./message-alerte.model";

/**
 * Interface Alerte
 */
export interface IAlerteProduitService {

  alerteRupture(message: MessageAlerte);

}
