import { ProduitDC } from "src/app/models/produit.model";

/**
 * Interface Alerte
 */
 export abstract class IProduitService {

  public abstract getProduits(): Promise<ProduitDC[]>;
}
