import { Injectable } from '@angular/core';
import { Produit } from 'openapi/build';
import { ProduitsRestService } from 'openapi/build/api/produitsRest.service';
import { ProduitDC } from 'src/app/models/produit.model';
import { IProduitService } from './abstract-produit.service';
//import { AlerteProduitPanierService as IAlerteProduitService } from './alerte/alerte-produit-panier.service';
import { AlerteProduitService as IAlerteProduitService } from './alerte/alerte-produit.service';
import { MessageAlerte } from './alerte/message-alerte.model';


/**
 * Service Produits - Métier
 */
@Injectable({
  providedIn: 'root'
})
export class ProduitsService implements IProduitService {

  constructor(public produitsRestService: ProduitsRestService,
              public alerteProduitService: IAlerteProduitService) { }

    /**
     * Retourne une liste de produits
     * @returns
     */
  public getProduits(): Promise<ProduitDC[]> {

    return this.produitsRestService.produitsControllerGetProduits()
      .toPromise()
      .then((produits) => produits
      .map((p) => this.testRupture(p))
    );
  }

  /**
   * Test les produits bientot en rupture.
   * Déclenche l'affichage de l'alerte.
   * @param p
   * @returns
   */
  private testRupture(p: ProduitDC) {
    if (p.quantite < 5) {
      // RG : Afficher l'alerte si la quantité est inférieur à 5
      this.alerteProduitService.alerteRupture({
          message: 'Produit bientôt en rupture',
          produit: p.nom,
          quantite: p.quantite
        } as MessageAlerte);
    }
    return p;
  };
}
