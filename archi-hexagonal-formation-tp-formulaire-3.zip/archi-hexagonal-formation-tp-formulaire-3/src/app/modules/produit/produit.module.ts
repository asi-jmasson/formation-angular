import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProduitComponent } from './produit.component';



@NgModule({
  declarations: [
    ProduitComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [ProduitComponent]
})
export class ProduitModule { }
