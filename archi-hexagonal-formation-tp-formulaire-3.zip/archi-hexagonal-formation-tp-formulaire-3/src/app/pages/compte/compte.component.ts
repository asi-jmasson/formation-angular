import { Component, OnInit, ViewChild } from '@angular/core';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatRadioGroup } from '@angular/material/radio';
import { Compte } from './interface/compte.interface';
import { CompteService } from './services/compte.service';

@Component({
  selector: 'app-compte',
  templateUrl: './compte.component.html',
  styleUrls: ['./compte.component.scss']
})
export class CompteComponent implements OnInit {

  public nouveauCompte: Compte;
  public currentCompte: Compte;
  public formsReady = false;
  public compteLabelSelected: string;
  public compteSelected = '2';
  public saveMonProfil = false;

  constructor(private compteService: CompteService) { }

  async ngOnInit(): Promise<void> {
    this.nouveauCompte = await this.compteService.getNouveauCompte();
    this.currentCompte = await this.compteService.getCurrentCompte();
    this.formsReady = true;
  }

  /**
   * Met à jour le compte modifié par le formulaire.
   * @param c 
   */
  public async updateCompte(c: Compte) {

    if (this.compteSelected == '2' && this.saveMonProfil) {
      this.compteService.setCurrentCompte(c);
      // important : pour l'attribut du composant
      this.currentCompte = await this.compteService.getCurrentCompte();
    }
    
    this.compteService.setCompteBdC(c);
  }

  public onChangeRadioGroup(radioGroup: MatRadioGroup) {

    console.log(radioGroup.value);
    
    if (radioGroup.value == '1') {
      this.compteLabelSelected = 'un nouveau compte';
      this.compteSelected = radioGroup.value;
    } else {
      this.compteLabelSelected = 'mon compte';
      this.compteSelected = radioGroup.value;
    }
    
  }

  public onChangeCheckBoxProfil(checkbox: MatCheckbox) {
    this.saveMonProfil = checkbox.checked;
  }

}
