import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';

import { FormulaireCompteComponent } from './formulaire-compte.component';

describe('FormulaireCompteComponent', () => {
  let component: FormulaireCompteComponent;
  let fixture: ComponentFixture<FormulaireCompteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormulaireCompteComponent ],
      providers: [FormBuilder]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FormulaireCompteComponent);
    component = fixture.componentInstance;
    component.compte = {
      firstName: 'toto',
      lastName: 'toto',
      email: 'tot@toto.fr',
      phone: '123456798'
    }
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
