import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Compte } from '../interface/compte.interface';

@Component({
  selector: 'app-formulaire-compte',
  templateUrl: './formulaire-compte.component.html',
  styleUrls: ['./formulaire-compte.component.scss']
})
export class FormulaireCompteComponent implements OnInit {

  @Input()
  public compte: Compte;

  @Output()
  public compteForm: EventEmitter<Compte> = new EventEmitter<Compte>();


  public profileForm: FormGroup;
  private emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initForm();
  }

  private initForm() {
    this.profileForm = this.fb.group({
      firstName: [this.compte.firstName, Validators.compose([Validators.required])],
      lastName: [this.compte.lastName, Validators.compose([Validators.required])],
      // email: ['', Validators.compose([Validators.required, Validators.email])]
      email: [this.compte.email, Validators.compose([Validators.required, Validators.pattern(this.emailPattern)])],
      phone: [this.compte.phone, Validators.compose([Validators.required])]
    })
  }

  /**
   * Assesseur get formulaire
   */
  get f() { return this.profileForm.controls}

  /**
   * Envoie le formulaire via param output
   * @param form 
   */
  public submit (form: Compte) {
    console.log('compte form', this.compte);
    console.log('submit form', form);

    if (form){
      this.compteForm.emit({...form});
    }
  }

  /**
   * Réinitialise les valeurs du formulaire
   */
  public resetForm() {
    this.initForm();
  }
}
