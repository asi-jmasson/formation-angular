import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BonCommandeComponent } from './bon-commande.component';



@NgModule({
  declarations: [
    BonCommandeComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [BonCommandeComponent]
})
export class BonCommandeModule { }
