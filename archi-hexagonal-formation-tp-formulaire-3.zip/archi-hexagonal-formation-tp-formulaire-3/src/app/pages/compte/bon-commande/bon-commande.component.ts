import { Component, Input, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Compte } from '../interface/compte.interface';
import { CompteService } from '../services/compte.service';

@Component({
  selector: 'app-bon-commande',
  templateUrl: './bon-commande.component.html',
  styleUrls: ['./bon-commande.component.scss']
})
export class BonCommandeComponent implements OnInit {

  private compteSubscription: Subscription;
  public compteDdC: Compte;
  public showBdc = false;

  constructor(private compteService: CompteService) { }

  ngOnInit(): void {

    this.compteSubscription = this.compteService.compteSubject.subscribe((c: Compte) => {
      this.compteDdC = c;
      this.showBdc = true;
    })
  }

  ngOnDestroy(): void {
    if (this.compteSubscription) {
      this.compteSubscription.unsubscribe();
    }
  }

}
