import { Injectable } from '@angular/core';
import { Compte } from '../interface/compte.interface';

@Injectable({
  providedIn: 'root'
})
export class HttpMockCompteService {

  constructor() { }


  getCompte() {
    return new Promise<Compte>((resolve, reject) => {
      console.log('# Request get current Compte !');
      
      resolve({
        firstName: 'Jean-Pierre',
        lastName:  'DUPONT',
        email: 'jp.dupont@ertdp.fr',
        phone: '0699887744'
      });
    })
  }

}
