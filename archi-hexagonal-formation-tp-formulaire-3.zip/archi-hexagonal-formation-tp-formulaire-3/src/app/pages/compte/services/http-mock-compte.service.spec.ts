import { TestBed } from '@angular/core/testing';

import { HttpMockCompteService } from './http-mock-compte.service';

describe('HttpMockCompteService', () => {
  let service: HttpMockCompteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpMockCompteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
