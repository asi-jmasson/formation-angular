import { flatten } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Compte } from '../interface/compte.interface';
import { HttpMockCompteService } from './http-mock-compte.service';

@Injectable({
  providedIn: 'root'
})
export class CompteService {

  private nouveauCompte: Compte;
  private currentCompte: Compte;
  public compteSubject = new Subject<Compte>();


  /**
   * 
   */
  constructor(private httpMockCompteService: HttpMockCompteService) {

    this.nouveauCompte = {
      firstName: '',
      lastName: '',
      email: '',
      phone: ''
    }
  }

  /**
   * Retourne une copie du compte courant.
   * @param force 
   * @returns 
   */
  public getCurrentCompte(force = false): Promise<Compte> {

    if(force || !this.currentCompte) {
      return this.httpMockCompteService.getCompte().then((c)=> {
        this.currentCompte = c;
        return {...this.currentCompte};
      });
    } else {
      return new Promise<Compte>((resolve) => {
        resolve({...this.currentCompte});
      });
    }
  }


  /**
   * Retoune un compte vide
   * @returns 
   */
  public getNouveauCompte(): Promise<Compte> {
    return new Promise<Compte>((resolve) => {
      resolve({...this.nouveauCompte});
    });
  }

  /**
   * Affecte les mises à jour dans le compte courant.
   * @param c 
   */
  public setCurrentCompte(c: Compte) {
    this.currentCompte = {...c};
    // todo : webservice post update compte
  }

  /**
   * Transfère aux observer le compte.
   * @param c 
   */
  public setCompteBdC(c: Compte) {
    this.compteSubject.next({...c});
  }

}
