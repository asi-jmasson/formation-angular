import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompteRoutingModule } from './compte-routing.module';
import { CompteComponent } from './compte.component';
import { FormulaireCompteModule } from './formulaire-compte/formulaire-compte.module';
import { BonCommandeModule } from "./bon-commande/bon-commande.module";
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';


@NgModule({
    declarations: [
        CompteComponent
    ],
    imports: [
        CommonModule,
        CompteRoutingModule,
        FormulaireCompteModule,
        BonCommandeModule,
        MatRadioModule,
        MatCheckboxModule,
    ]
})
export class CompteModule { }
