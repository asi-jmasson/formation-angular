import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormulaireCompteComponent } from './formulaire-compte.component';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    FormulaireCompteComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  exports: [
    FormulaireCompteComponent
  ]
})
export class FormulaireCompteModule { }
