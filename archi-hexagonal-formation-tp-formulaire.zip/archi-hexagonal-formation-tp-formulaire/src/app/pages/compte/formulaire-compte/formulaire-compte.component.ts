import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-formulaire-compte',
  templateUrl: './formulaire-compte.component.html',
  styleUrls: ['./formulaire-compte.component.scss']
})
export class FormulaireCompteComponent implements OnInit {


  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
  
  }

}
