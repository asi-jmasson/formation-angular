import { TestBed } from '@angular/core/testing';

import { ProduitsPanierService } from './produits-panier.service';

describe('ProduitsPanierService', () => {
  let service: ProduitsPanierService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProduitsPanierService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
