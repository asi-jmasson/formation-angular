import { ProduitDC } from "src/app/models/produit.model";

/**
 * Interface Alerte
 */
 export abstract class IProduitService {

  constructor() {}

  public abstract getProduits(): Promise<ProduitDC[]>;
}
