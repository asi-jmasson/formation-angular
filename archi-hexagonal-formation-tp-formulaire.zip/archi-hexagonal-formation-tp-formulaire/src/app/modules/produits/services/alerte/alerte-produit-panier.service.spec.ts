import { TestBed } from '@angular/core/testing';

import { AlerteProduitPanierService } from './alerte-produit-panier.service';

describe('AlerteProduitPanierService', () => {
  let service: AlerteProduitPanierService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlerteProduitPanierService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
