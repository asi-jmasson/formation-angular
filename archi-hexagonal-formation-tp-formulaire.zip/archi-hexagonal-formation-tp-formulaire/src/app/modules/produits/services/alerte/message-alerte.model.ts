/**
 * Models des alertes
 */

export interface MessageAlerte {
  message: string;
}

export interface MessageAlerteProduit extends MessageAlerte {
  produit: string;
}

export interface MessageAlertePanier extends MessageAlerteProduit {
  quantite: string;
}
