import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PanierComponent } from './panier.component';
import { ProduitModule } from '../produit/produit.module';
import { PanierInfoBulleModule } from '../panier-info-bulle/panier-info-bulle.module';



@NgModule({
  declarations: [
    PanierComponent
  ],
  imports: [
    CommonModule,
    ProduitModule,
    PanierInfoBulleModule,
  ],
  exports: [
    PanierComponent
  ]
})
export class PanierModule { }
