import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ProduitDC } from 'src/app/models/produit.model';
import { PanierService } from './services/panier.service';

@Component({
  selector: 'app-panier',
  templateUrl: './panier.component.html',
  styleUrls: ['./panier.component.scss']
})
export class PanierComponent implements OnInit {

  private panierSubscription: Subscription;
  public produits: ProduitDC[] = [];

  constructor(private panierService: PanierService) { }

  ngOnInit(): void {

    this.produits = this.panierService.produitsList;

    this.panierSubscription = this.panierService.panierSubject.subscribe((produits: ProduitDC[])=> {
      this.produits = produits;
    });

  }

  ngOnDestroy() {
    this.panierSubscription.unsubscribe();
  }

}
