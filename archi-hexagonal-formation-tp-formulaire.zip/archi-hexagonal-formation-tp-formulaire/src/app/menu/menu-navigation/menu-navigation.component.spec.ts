import {ComponentFixture, TestBed} from '@angular/core/testing';
import {KeycloakService} from 'keycloak-angular';
import {AuthenticationControllerService} from 'openapi/build/api/authenticationController.service';

import {MenuNavigationComponent} from './menu-navigation.component';
import {MenuService} from '../../services/menu.service';
import {of} from 'rxjs';
import {Router} from '@angular/router';

describe('MenuNavigationComponent', () => {
  let component: MenuNavigationComponent;
  let fixture: ComponentFixture<MenuNavigationComponent>;

  const mockedKeyCloakService = jasmine.createSpyObj('KeyCloakService', ['isLoggedIn', 'isUserInRole']);
  const mockedAuthenticationControllerService = jasmine.createSpyObj('AuthenticationControllerService', ['handleUserInfoRequest']);
  const mockedMenuService = jasmine.createSpyObj('MenuService', ['showMenuRemplacement']);
  const mockedRouter = jasmine.createSpyObj('Router', ['navigate']);

  mockedMenuService.menuRemplacement = of(true);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MenuNavigationComponent],
      providers: [
        {provide: Router, useValue: mockedRouter},
        {provide: AuthenticationControllerService, useValue: mockedAuthenticationControllerService},
        {provide: KeycloakService, useValue: mockedKeyCloakService},
        {provide: MenuService, useValue: mockedMenuService},
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
