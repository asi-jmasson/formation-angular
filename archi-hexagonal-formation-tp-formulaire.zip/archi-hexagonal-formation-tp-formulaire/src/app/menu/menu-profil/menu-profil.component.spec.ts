import {ComponentFixture, TestBed} from '@angular/core/testing';

import {MenuProfilComponent} from './menu-profil.component';
import {KeycloakService} from 'keycloak-angular';
import {MatMenuModule} from '@angular/material/menu';
import {MenuService} from '../../services/menu.service';

describe('MenuProfilComponent', () => {
  let component: MenuProfilComponent;
  let fixture: ComponentFixture<MenuProfilComponent>;

  const mockedKeyCloakService = jasmine.createSpyObj('KeyCloakService', ['keyCloak']);
  const mockedMenuService = jasmine.createSpyObj('MenuService', ['getMenuParam']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MenuProfilComponent],
      imports: [MatMenuModule],
      providers: [
        {provide: KeycloakService, useValue: mockedKeyCloakService},
        {provide: MenuService, useValue: mockedMenuService},
      ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuProfilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
