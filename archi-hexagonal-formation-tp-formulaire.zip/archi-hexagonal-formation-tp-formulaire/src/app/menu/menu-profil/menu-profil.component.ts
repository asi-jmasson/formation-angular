import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-profil',
  templateUrl: './menu-profil.component.html',
  styleUrls: ['./menu-profil.component.scss']
})
export class MenuProfilComponent implements OnInit {

  constructor() {}

  public async ngOnInit(): Promise<void> {
  }

  public logout() {
  }
}
